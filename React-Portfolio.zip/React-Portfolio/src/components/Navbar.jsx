import React, { useEffect } from 'react';

function Navbar() {
  useEffect(() => {
    const handleScroll = () => {
      const navbar = document.querySelector('.navbar');
      const sections = document.querySelectorAll('section');
      const navLinks = document.querySelectorAll('.navbar a');
      
      // Add scrolled class to navbar
      if (window.scrollY > 100) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
      
      sections.forEach(section => {
        const sectionTop = section.offsetTop - 60;
        const sectionHeight = section.clientHeight;
        if (window.pageYOffset >= sectionTop && window.pageYOffset < sectionTop + sectionHeight) {
          const currentSection = section.getAttribute('id');
          navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').substring(1) === currentSection) {
              link.classList.add('active');
            }
          });
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = (e) => {
    e.preventDefault();
    const targetId = e.target.getAttribute('href').substring(1);
    const element = document.getElementById(targetId);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 50,
        behavior: 'smooth'
      });
    }
  };

  return (
    <nav className="navbar">
      <ul>
        <li><a href="#about" onClick={handleClick}>About Me</a></li>
        <li><a href="#skills" onClick={handleClick}>Skills</a></li>
        <li><a href="#portfolio" onClick={handleClick}>Portfolio</a></li>
        <li><a href="#contact" onClick={handleClick}>Contact</a></li>
      </ul>
    </nav>
  );
}

export default Navbar; 