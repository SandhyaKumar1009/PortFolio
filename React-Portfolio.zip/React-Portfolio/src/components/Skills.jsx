import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCode, faPalette, faComments } from '@fortawesome/free-solid-svg-icons';

function Skills() {
  return (
    <section id="skills" className="skills">
      <h2>My Skills</h2>
      <div className="skills-grid">
        <div className="skill-card">
          <FontAwesomeIcon icon={faCode} />
          <h3>Programming</h3>
          <p>Fluent in Python, C, and Java. Efficient code for dynamic solutions.</p>
        </div>
        <div className="skill-card">
          <FontAwesomeIcon icon={faPalette} />
          <h3>Design</h3>
          <p>Passionate about crafting intuitive and aesthetic user experiences.</p>
        </div>
        <div className="skill-card">
          <FontAwesomeIcon icon={faComments} />
          <h3>Communication</h3>
          <p>Proficient in presentations and storytelling with a dynamic edge.</p>
        </div>
      </div>
    </section>
  );
}

export default Skills; 