import React from 'react';
import { motion } from 'framer-motion';
import sandhyaImage from '../assets/Sandhya.jpg';

function About() {
  return (
    <section id="about" className="about">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        Hello, I'm Sandhya
      </motion.h2>
      
      <div className="about-content">
        <motion.div 
          className="about-image-container"
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <img src={sandhyaImage} alt="Sandhya" className="about-image" />
        </motion.div>

        <motion.div 
          className="about-text"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <p>
            Currently pursuing my II year at Sri Eshwar College Of Engineering, 
            I serve as the Vice President Of Education in Sri Eshwar ToastMasters club 
            and as a Student Mentor in the Mentoring Club.
          </p>
        </motion.div>

        <div className="stats-container">
          {[
            { number: "2+", label: "Years Experience in SETC" },
            { number: "3+", label: "Projects Completed" },
            { number: "150+", label: "Solved Problems on Leetcode" }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              className="stat-card"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
            >
              <div className="stat-number">{stat.number}</div>
              <div className="stat-label">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default About; 