import React from 'react';
import { motion } from 'framer-motion';

function Resume() {
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = '/Sandhya_Resume.pdf';  // Updated path
    link.download = 'Sandhya_Resume.pdf';
    link.click();
  };

  return (
    <section id="resume" className="resume">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="resume-container"
      >
        <h2>My Resume</h2>
        <div className="resume-viewer">
          <object 
            data="/Sandhya_Resume.pdf"
            type="application/pdf"
            width="100%"
            height="800px"
          >
            <p>Unable to display PDF file. <a href="/Sandhya_Resume.pdf" download>Download</a> instead.</p>
          </object>
        </div>
        
      </motion.div>
    </section>
  );
}

export default Resume; 