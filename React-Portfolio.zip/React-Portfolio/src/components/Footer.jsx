import React from 'react';

function Footer() {
  return (
    <footer>
      <p>&copy; {new Date().getFullYear()} Sandhya's Vibrant Space. Designed with 💖 and creativity.</p>
    </footer>
  );
}

export default Footer; 