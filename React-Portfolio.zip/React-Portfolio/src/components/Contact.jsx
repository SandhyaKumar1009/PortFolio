import React from 'react';
import { motion } from 'framer-motion';

function Contact() {
  const handleContact = () => {
    window.location.href = 'mailto:sandhya.a2023ai-ds@sece.ac.in';
  };

  return (
    <section id="contact" className="contact">
      <h2>Contact Me</h2>
      <p>Have a project or idea to discuss? Let's connect!</p>
      <motion.button
        className="btn-main"
        onClick={handleContact}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        Get in Touch
      </motion.button>
    </section>
  );
}

export default Contact; 