import React from 'react';
import { motion } from 'framer-motion';

function Portfolio() {
  const projects = [
    {
      title: "Privacy Pros",
      description: "A cyber project calculating privacy policy scores using Sentiment Analysis",
      tech: ["Python", "NLP", "Machine Learning"],
      category: "AI/ML"
    },
    {
      title: "YouTube Popularity Predictor",
      description: "ML model to predict video popularity using engagement metrics",
      tech: ["Python", "Machine Learning", "Data Analysis"],
      category: "AI/ML"
    },
    {
      title: "Secure Bot",
      description: "AI-powered Telegram bot detecting suspicious drug-related conversations",
      tech: ["Python", "NLP", "Telegram API"],
      category: "AI/ML"
    }
  ];

  return (
    <section id="portfolio" className="portfolio">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        Featured Projects
      </motion.h2>
      
      <div className="projects">
        {projects.map((project, index) => (
          <motion.div
            key={project.title}
            className="project-card"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.2 }}
          >
            <span className="category">{project.category}</span>
            <h3>{project.title}</h3>
            <p>{project.description}</p>
            <div className="tech-stack">
              {project.tech.map(tech => (
                <span key={tech} className="tech-tag">{tech}</span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export default Portfolio; 