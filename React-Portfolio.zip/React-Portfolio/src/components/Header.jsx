import React from 'react';
import { motion } from 'framer-motion';

function Header() {
  const roles = ["ML Developer", "AI Enthusiast", "Java Developer"];

  return (
    <header className="hero">
      <div className="hero-content">
        <motion.h1
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          Sandhya A
        </motion.h1>
        
        <div className="roles-container">
          {roles.map((role, index) => (
            <motion.div
              key={role}
              className="role"
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.2 }}
            >
              {role}
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <a href="#about" className="btn-main">Explore My Journey</a>
        </motion.div>
      </div>
    </header>
  );
}

export default Header; 